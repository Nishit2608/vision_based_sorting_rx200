# sorting_using_nvidia_stack > 2025-04-17 6:53pm
https://universe.roboflow.com/wildfiredetection-v4tt4/sorting_using_nvidia_stack

Provided by a Roboflow user
License: CC BY 4.0

